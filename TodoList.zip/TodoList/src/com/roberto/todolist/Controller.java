package com.roberto.todolist;

import com.roberto.todolist.datamodel.TodoItem;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextArea;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Controller
{
    private List<TodoItem> todoItems = new ArrayList<>();
    @FXML
    private ListView<TodoItem> todoListView;
    @FXML
    private TextArea itemDetailsTextArea;
    @FXML
    private Label dueLabel;

    public void initialize()
    {

        populateTodoItems(todoItems);
        todoListView.getItems().setAll(todoItems);
        todoListView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<TodoItem>() {
            @Override
            public void changed(ObservableValue<? extends TodoItem> observable, TodoItem oldValue, TodoItem newValue)
            {
                if(newValue != null)
                {
                    TodoItem item = todoListView.getSelectionModel().getSelectedItem();
                    itemDetailsTextArea.setText(item.getDetails());
                    DateTimeFormatter df = DateTimeFormatter.ofPattern("d/MM/yyyy");
                    dueLabel.setText(df.format(item.getDeadline()));
                }
            }
        });
        todoListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        todoListView.getSelectionModel().selectFirst();
    }

    private void populateTodoItems(List<TodoItem> todoItems)
    {
        TodoItem item1 = new TodoItem("Mail birthday card", "Buy a 30th birthday card for John",
                LocalDate.of(2017, Month.APRIL, 25));
        TodoItem item2 = new TodoItem("Doctor's Appointment", "See Dr. Smith at 123 Street." +
                "Bring Paperwork",
                LocalDate.of(2017, Month.MAY, 11 ));
        TodoItem item3 = new TodoItem("Finish design proposal for client",
                "I promised Mike i'd email website proposal mockups",
                LocalDate.of(2017, Month.JULY, 10));
        TodoItem item4 = new TodoItem("Take my Cat to the vet", "Need to take my house cat for a check up",
                LocalDate.of(2018, Month.MARCH, 25));
        TodoItem item5 = new TodoItem("Return book", "Must return an overdue book to the public library",
                LocalDate.of(2018, Month.MARCH, 15));
        todoItems.add(item1);
        todoItems.add(item2);
        todoItems.add(item3);
        todoItems.add(item4);
        todoItems.add(item5);
    }

    @FXML
    public void handleClickListView()
    {
        TodoItem item = todoListView.getSelectionModel().getSelectedItem();
        itemDetailsTextArea.setText(item.getDetails());
        dueLabel.setText(item.getDeadline().toString());
    }
}
